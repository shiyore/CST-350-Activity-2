﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstApplication.Controllers
{
    public class ProductsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Message()
        {
            return View();
        }
        public IActionResult Welcome()
        {
            ViewBag.name = "Aiden";
            ViewBag.secretNum = 13;
            return View(); 
        }
    }
}
