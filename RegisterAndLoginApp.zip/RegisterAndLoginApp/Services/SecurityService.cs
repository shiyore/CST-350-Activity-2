﻿using RegisterAndLoginApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterAndLoginApp.Services
{ 
    public class SecurityService
    {

        List<UserModel> knownUsers = new List<UserModel>();
        SecurityDAO dao = new SecurityDAO();

        public SecurityService()
        {
                
        }

        public bool IsValid(UserModel user)
        {
            return dao.FindUser(user);
        }
    }
}
