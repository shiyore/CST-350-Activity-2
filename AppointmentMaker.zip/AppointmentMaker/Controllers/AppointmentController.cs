﻿using AppointmentMaker.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentMaker.Controllers
{
    public class AppointmentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Details(AppointmentModel appointment)
        {
            if (appointment.netWorth < 90000)
                return View("TooPoor");
            if (appointment.painLevel < 5)
                return View("Wuss");
            return View("Details", appointment);
        }
    }
}
