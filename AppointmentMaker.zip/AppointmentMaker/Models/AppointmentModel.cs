﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentMaker.Models
{
    public class AppointmentModel
    {
        [Required]
        [StringLength(20,MinimumLength =4)]
        [DisplayName("Patient's full name")]
        public string patientName { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Appointment Request Date")]
        public DateTime appointmentDate { get; set; }
        
        [Required]
        [DataType(DataType.Text)]
        [StringLength(20, MinimumLength = 6)]
        [DisplayName("Primary Doctor")]
        public string doctorName { get; set; }
        
        [Required]
        [DataType(DataType.Currency)]
        [Range(1,10000000)]
        [Column(TypeName = "decimal(18, 2)")]
        [DisplayName("Patient's Net Worth")]
        public int netWorth { get; set; }
        [Required]
        [Range(1,10)]
        [DisplayName("Patient's Level Of pain")]
        public int painLevel { get; set; }

        //coding challenge sections
        [Required]
        [DataType(DataType.Text)]
        [StringLength(20, MinimumLength = 10)]
        [DisplayName("Street Address")]
        public int StreetAddress{ get; set; }
        [Required]
        [DataType(DataType.Text)]
        [StringLength(20, MinimumLength = 10)]
        [DisplayName("City")]
        public int city { get; set; }
        [Required]
        [DataType(DataType.Text)]
        [StringLength(20, MinimumLength = 2)]
        [DisplayName("State")]
        public int state { get; set; }
        [Required]
        [DataType(DataType.PostalCode)]
        [DisplayName("Postal Code")]
        public int zipCode { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        [DisplayName("Email Address")]
        public int email { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        [DisplayName("Phone Number")]
        public int phoneNumber { get; set; }



        public AppointmentModel()
        {

        }
    }

}
